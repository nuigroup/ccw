# /bin/sh
/Applications/CCW/data/plugins/MySQL/bin/mysqld_safe --defaults-file=/Applications/CCW/data/plugins/MySQL/control/my.cnf --user=mysql &
