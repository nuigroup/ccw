<?php 
phpinfo(); 
?>