# /bin/sh
/Applications/CCW/data/plugins/MySQL/bin/mysqladmin --socket=/Applications/CCW/data/plugins/MySQL/tmp/mysql.sock --user=root --pass=root shutdown
